## Bootstrap Wordpress Theme YouTube Series

This is the source code for the YouTube series. It includes the following...

  - The HTML template for the posts page and front page
  - The Wordpress theme folder
  - Resources such as the images and the navwalker class file